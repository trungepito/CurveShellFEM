# CurveShellFEM Agent System — Improvement Package (v2.0)

## What's in this package

```
AGENT_CHARTER.md                    ← Single source of truth for the entire ecosystem
agents/
  Lead_Architect_Instructions.md
  FEM_Expert_Analyst_Instructions.md
  Core_Implementer_Instructions.md
  Validation_Scientist_Instructions.md
  Specialist_Instructions.md        ← Systems Engineer + Preprocessor Specialist
                                       + Visualization Expert + Documentation Assistant
workflows/
  All_Workflows.md                  ← All 8 workflows in one file with consistent metadata
skills/
  Skill_Library.md                  ← 10 domain skills (SK-01 through SK-10)
templates/
  Report_Templates.md               ← 5 report templates (A–E)
```

## Key improvements vs. current system

| Area | Before | After |
|:-----|:-------|:------|
| Charter / ground truth | Scattered across individual files | Single `AGENT_CHARTER.md` governs all |
| Agent instructions | Mix of mandate + contributions + prompts in one file | Mandate / authority / workflows / prompts cleanly separated |
| Workflow metadata | Inconsistent — some have `applyTo`, some have `description` only | Uniform YAML front-matter: `trigger`, `agents`, `phase_type`, `outputs` |
| Skills | "nonlinear-solver-workflow.md" mixes workflow + skill | Skills = reference (how to do X correctly); workflows = procedure (steps to follow) |
| Report templates | Two templates, neither enforced | Five templates (A–E), one per agent role, with mandatory fields |
| Reporting protocol | Defined in one file, inconsistently referenced | Defined in charter §3, agent files all point to it |
| Verdict system | "APPROVE / REFINE / REJECT" with no "CAUTION" | "PASS / REFINE / CAUTION / REJECT" with clear implementer actions per verdict |
| `file:///` paths | Machine-local absolute paths in many documents | Flagged in `sync-docs` workflow; should be relative paths |
| Agent profiles (contributions) | Mix of "Planned" and "Completed" creating confusion | Profiles are living documents; completed work is in reports, not profiles |

## Installation

Replace the contents of `.agent/` with these files. Update references from the old individual instruction files to point to this package.

Recommended `.agent/` layout after installation:
```
.agent/
  AGENT_CHARTER.md
  agents/
    Lead_Architect_Instructions.md
    FEM_Expert_Analyst_Instructions.md
    Core_Implementer_Instructions.md
    Validation_Scientist_Instructions.md
    Systems_Engineer_Instructions.md
    Preprocessor_Specialist_Instructions.md
    Visualization_Expert_Instructions.md
    Documentation_Assistant_Instructions.md
  workflows/
    manage-project.md
    review-architecture.md
    control-data-flow.md
    add-element-type.md
    debug-nonlinear-convergence.md
    run-unit-tests.md
    audit-reporting.md
    sync-docs.md
  skills/
    SK-01_Shell_Element_Formulation.md
    SK-02_J2_Plasticity.md
    SK-03_Arc_Length_Solver.md
    SK-04_Sparse_Assembly.md
    SK-05_History_Variables.md
    SK-06_Class_Hierarchy.md
    SK-07_Convergence_Diagnosis.md
    SK-08_Benchmark_Setup.md
    SK-09_Mesh_Quality.md
    SK-10_Postprocessing.md
  templates/
    Analyst_Report_Template.md
    Validation_Report_Template.md
    Implementer_Report_Template.md
    Systems_Report_Template.md
    Architect_Phase_Completion_Template.md
```

Note: the current package delivers these in consolidated files for convenience.
Split them into individual files as shown above for the `.agent/` installation.
