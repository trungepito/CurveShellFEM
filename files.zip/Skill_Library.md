# Skill Library — CurveShellFEM (v2.0)

> Skills are reference documents, not workflows. They answer "how do I do X correctly?" for recurring technical challenges.
> Read the relevant skill before acting, not after.

---

## Skill Index

| ID | Skill | Domain | Read Before |
|:---|:------|:-------|:------------|
| SK-01 | Shell element formulation | FEM Analyst | Any new element implementation |
| SK-02 | J2 plasticity & return mapping | FEM Analyst, Implementer | Any material model work |
| SK-03 | Arc-length solver | FEM Analyst, Implementer | Any arc-length modification |
| SK-04 | Sparse assembly patterns | Core Implementer | Any assembly code |
| SK-05 | History variable management | Implementer, Systems Engineer | Any stateful element work |
| SK-06 | MATLAB class hierarchy | Core Implementer | Any new class creation |
| SK-07 | Nonlinear convergence diagnosis | All | Any convergence issue |
| SK-08 | Benchmark setup & reporting | Validation Scientist | Any benchmark execution |
| SK-09 | Mesh quality assessment | Preprocessor Specialist | Any mesh generation |
| SK-10 | Post-processing & stress recovery | Visualization Expert | Any postprocessor work |

---

## SK-01 — Shell Element Formulation

**Domain**: FEM Analyst (theory), Core Implementer (code)

### The 8-node serendipity shell element (40-DOF local / 48-DOF global)

**Local DOF ordering** (5 DOFs per node: u, v, w, α, β):
Node order: (-1,-1), (1,-1), (1,1), (-1,1), (0,-1), (1,0), (0,1), (-1,0)

**Global DOF ordering** (6 DOFs per node: u, v, w, Rv1, Rv2, Wz):
The drilling DOF Wz is stabilised with a penalty stiffness: `k_drill = 1e-4 × mean(diag(Ke_mixed))`.

**Transformation chain**:
```
Global 48-DOF  →  T_hybrid (rotation)  →  48-DOF local  →  strip drilling  →  40-DOF  →  per_5_blkdiag (permute)  →  mixed basis
```
`T_hybrid` is cached in `obj.T_cached` at construction — never recompute per step.

**Integration scheme** (standard element):
- Membrane/bending: 3×3 Gauss in-plane
- Shear: 2×2 Gauss in-plane (reduced to prevent shear locking)
- Plasticity (tangent stiffness): 2×2 Gauss in-plane × 5 Simpson through-thickness

**ANS (Bathe-Dvorkin) sampling points**:
- γ_ξz: sample at A=(0,+1) and B=(0,−1)
- γ_ηz: sample at C=(+1,0) and D=(−1,0)
- Interpolation: `γ̄_ξz = ½(1+η)·γ_ξz^A + ½(1−η)·γ_ξz^B`

**EAS parameters** (4-parameter Simo-Rifai for membrane locking):
The 4-parameter basis `M(ξ,η)` must satisfy:
1. M(0,0) = 0 (patch test)
2. ∫M dV = 0 (orthogonality to constant stress fields)

Static condensation:
```
K_e = K_uu − K_uα · K_αα⁻¹ · K_αu
```
`K_αα` condition number should be < 10 for a well-conditioned condensation.

**Zero-energy mode count** (correct values):
- Base `Curve8Element`: 6 rigid body modes (no spurious modes with 3×3 membrane integration)
- With ANS only: 6 modes
- With EAS: 6 modes (EAS removes spurious membrane modes present in under-integrated elements)

---

## SK-02 — J2 Plasticity & Return Mapping

**Domain**: FEM Analyst (theory), Core Implementer (code)

### Plane-stress J2 return mapping (iterative Newton)

**Yield function**: `f = σ_VM − (σ_Y + H·p)` where `σ_VM = √(σx² + σy² − σx·σy + 3τxy²)`

**Trial stress**: `σ_trial = D_el · (ε_total − ε_p_old)`

**Elastic check**: `f_trial ≤ 1e-6 · σ_Y` → elastic, return `σ = σ_trial`, `D_ep = D_el`

**Plastic return mapping** (backward Euler):
The system `M·σ = σ_trial` where `M = I + ΔΓ·D_el·P` must be solved iteratively because M depends on ΔΓ.
- Newton update: `ΔΓ_{k+1} = ΔΓ_k − φ/φ'`
- Damping: multiply Newton step by 0.8 to prevent oscillation near sharp limit
- Convergence: `|φ| < 1e-8·σ_Y`

**Consistent Algorithmic Tangent (ATM)**:
```
D_ep = D_r − (D_r·n·n'·D_r) / (n'·D_r·n + H)
```
where `D_r = (M \ D_el)` and `n = (1/σ_VM)·[σx − ½σy; σy − ½σx; 3τxy]`

**Critical**: `D_ep` must be computed at the converged ΔΓ, not at the trial state. Using the trial tangent causes loss of quadratic convergence.

**History variables** per Gauss point:
```matlab
struct('sigma', [0;0;0], 'eps_p', [0;0;0], 'p', 0)
```
Number of integration points: 2×2 in-plane × 5 Simpson = 20 per element.

---

## SK-03 — Arc-Length Solver

**Domain**: FEM Analyst (theory), Core Implementer (code), Systems Engineer (state)

### Modified Riks / Hyperplane constraint

**Constraint function**:
```
g = dup' · (u − u₁) + ψ²·dlp·(λ − λ₁) = 0
```
where `u₁ = u₀ + dlp·dup`, `λ₁ = λ₀ + dlp`, and `ψ` is the load-scaling factor.

**Gradients**: `h = dup` (∂g/∂u), `s = ψ²·dlp` (∂g/∂λ)

**Guard**: if `|s| < 1e-14`, set `s = arc_length · ψ²` to prevent denominator collapse on the first step.

### Corrector (augmented Newton)

Solve the partitioned system on **free DOFs only**:
```
KT_ff · du_I   =  fext_f       (tangent load direction)
KT_ff · du_II  = −R_f          (equilibrium correction)
```
Load factor increment: `dλ = −(g + h_f'·du_II) / (s + h_f'·du_I)`
Displacement increment: `du = dλ·du_I + du_II` (on free DOFs only)

**Fixed DOFs**: set `R(fixed_dofs) = 0` in the assembly closure. Never include them in the linear system.

**Residual sign** (correct): `R = F_int − λ·F_ext`

**Convergence criterion**: `‖R(free_dofs)‖ ≤ tol · ‖fext(free_dofs)‖`

### CSP (Current Stiffness Parameter) for snap-back detection

```matlab
k0 = dot(dup_prev, dup_curr)   % dup_curr = KT_ff \ fext_f
```
If `k0 < 0`: path has turned back → negate `dlp` (unloading predictor).

**Common mistake**: using `dot(fext, dup)` for CSP. This is always positive for SPD systems and cannot detect snap-back.

### Adaptive radius policy

| Condition | Action |
|:----------|:-------|
| iters ≤ 4 | `arc = min(arc × 1.5, arc_max)` |
| 4 < iters ≤ 0.75·maxit | `arc` unchanged |
| iters > 0.75·maxit | `arc = max(arc × 0.7, arc_min)` |
| Step fails | `arc = max(arc × 0.5, arc_min)`, retry (max 5 trials) |

---

## SK-04 — Sparse Assembly Patterns

**Domain**: Core Implementer

### Triplet assembly (correct pattern)

```matlab
% Pre-allocate
nz = 48*48 * nElems;
I = zeros(nz, 1); J = zeros(nz, 1); V = zeros(nz, 1);
count = 0;

for e = 1:nElems
    sctr = obj.SctrMap(e, :);              % 1×48 pre-computed
    Ke = obj.Elements{e}.computeGlobalMatrix6DOF(u_el);  % 48×48
    
    range = count + (1:48*48);
    [ii, jj] = ndgrid(sctr, sctr);         % not meshgrid — ndgrid is correct for column-major
    I(range) = ii(:);
    J(range) = jj(:);
    V(range) = Ke(:);
    count = count + 48*48;
end
K = sparse(I(1:count), J(1:count), V(1:count), nDofs, nDofs);
```

**Never**: `K(sctr, sctr) = K(sctr, sctr) + Ke` inside a loop — this re-allocates the sparse matrix at every iteration.

### SctrMap pre-computation (once in buildElementCache)

```matlab
sctr = zeros(1, 48);
for n = 1:8
    start_dof = (double(idx(n)) - 1) * 6;   % double() prevents int32 arithmetic overflow
    local_start = (n - 1) * 6;
    sctr(local_start+1 : local_start+6) = start_dof + (1:6);
end
obj.SctrMap(e, :) = sctr;
```

---

## SK-05 — History Variable Management

**Domain**: Core Implementer, Systems Engineer

### The trial-commit pattern (mandatory for any stateful element)

```
Assembly call  →  element returns TrialHist (new state)
                ↓
Newton iteration converges?
    YES  →  solver.commitHistory(TrialHist)  →  element.HistoryData updated
    NO   →  TrialHist discarded, element.HistoryData unchanged (still at last committed state)
```

**Implementation in `commitHistory`**:
```matlab
function commitHistory(obj, TrialHist)
    if isempty(TrialHist), return; end
    for e = 1:length(obj.Elements)
        if isprop(obj.Elements{e}, 'HistoryData') && ~isempty(TrialHist{e})
            obj.Elements{e}.HistoryData = TrialHist{e};
        end
    end
end
```

**Initialisation** (in `buildElementCache`):
```matlab
nGP = 4 * 5;  % 2×2 Gauss × 5 Simpson
init_h = struct('sigma', zeros(3,1), 'eps_p', zeros(3,1), 'p', 0);
hist = repmat(init_h, nGP, 1);
obj.Elements{e} = Curve8Element(coords, normals, t, E, nu, mat.Obj, hist);
```

**Diagnostic**: after a converged plastic step, all elements that yielded must have `p > 0`. If `p = 0` everywhere, `commitHistory` was not called.

---

## SK-06 — MATLAB Class Hierarchy

**Domain**: Core Implementer

### Inheritance chain
```
handle
  └── FEM_Solver
        └── FEM_Solver_Nonlinear  (+ events: StepConverged)
              ├── FEM_Solver_Adaptive
              │     └── FEM_Solver_ArcLength
              └── (future: FEM_Solver_DynamicImplicit)

handle
  └── Curve8Element
        └── Curve8Element_ANS_EAS
        └── Curve8Element_GNI
        └── (future: Curve8Element_Thermal)
```

### Rules
- New element subclasses override only the methods that differ from the base.
- New solver subclasses inherit `newtonLoop`, `linesearch`, `commitHistory`, `calculateGlobalTargetForce`, `getDispload` from `FEM_Solver_Nonlinear` without modification.
- `buildElementCache` dispatches using `isfield(mat, 'Type')` or `isfield(mat, 'ElementType')`. Prefer `isa(mat.Obj, 'Material_*')` for material dispatch — avoids string typos.
- `events` block lives only in `FEM_Solver_Nonlinear`. Subclasses call `notify(obj, 'StepConverged', evtData)`.

---

## SK-07 — Nonlinear Convergence Diagnosis

**Domain**: All agents

### Quick classification

| Symptom | Most likely cause | First check |
|:--------|:-----------------|:------------|
| Residual oscillates | Inconsistent KT and F_int | Check `computeTangentStiffnessAndForce` returns consistent pair |
| Residual grows monotonically | Wrong sign in residual | Confirm `R = F_int − λ·F_ext` (not `F_ext − F_int`) |
| `condest(KT_ff) ≈ 0` on first step | Fixed DOFs in the linear system | Confirm `KT(free_dofs, free_dofs)` used |
| Converges in 1 iteration always | Convergence criterion checking full R not free-DOF R | Confirm `norm(R(free_dofs))` |
| `p = 0` after plastic step | `commitHistory` not called | Trace `commitHistory` call |
| Correct path then diverges at limit point | Arc-length radius too large | Reduce `ArcLengthRadius` by 50% |
| Snap-back not detected | CSP uses `dot(fext, dup)` | Fix to `dot(dup_prev, dup_curr)` |
| Linear convergence rate (not quadratic) | ATM not consistent | Check `integrateStress` returns exact ATM |

---

## SK-08 — Benchmark Setup & Reporting

**Domain**: Validation Scientist

### Standard benchmarks and their configuration

| Benchmark | Reference | Mesh | Solver | Target metric | Target tolerance |
|:----------|:----------|:-----|:-------|:--------------|:-----------------|
| Scordelis-Lo Roof | Scordelis & Lo (1964) | 20×20 | Linear static | Max vertical displacement at free edge | < 0.2% vs. 0.3024 |
| Pinched Cylinder | Macneal & Harder (1985) | Variable | Linear static | Displacement at load point | < 1% vs. theory |
| ANS/EAS curved element | Internal | Single element, R=300, t=3 | Stiffness check | Stiffness trace ratio | < 1.0 (softer than base) |
| Plastic snap-through | Crisfield (1981) | 4×4 | Arc-Length | Limit point traversal; `p > 0` post-yield | Converges; no state leak |
| Buckling plate | Timoshenko & Gere | 10×10 | Linear buckling | Critical load `P_cr` | < 2% vs. theory |

### Benchmark script structure
```matlab
% 1. Setup
Pre = FEM_Preprocessor_v2(E, nu, t);
Pre.createCylinderPanel(...);
Pre.meshAllPatches(20, 20);
Pre.addBC(...); Pre.addNodalLoad(...);

% 2. Solve
Sol = FEM_Solver(Pre);
Sol.solveStatic();

% 3. Measure
u_max = max(abs(Sol.U(3:6:end)));  % z-displacement

% 4. Compare
ref = 0.3024;
err = abs(u_max - ref) / ref * 100;
fprintf('Error: %.4f%%\n', err);
assert(err < 0.2, 'Scordelis-Lo benchmark FAILED');
```

---

## SK-09 — Mesh Quality Assessment

**Domain**: Preprocessor Specialist

### Jacobian determinant check (mandatory for new mesh generators)

```matlab
function ok = checkMeshDistortion(Pre, threshold)
% threshold: max allowed det(J) ratio (max/min per element)
% Returns false if any element exceeds threshold (recommended: 10)
nElems = size(Pre.Mesh.Elements, 1);
ok = true;
[g_pts, ~] = MathFEM.Gauss_p(2);
for e = 1:nElems
    idx = Pre.Mesh.Elements(e,:);
    el = Curve8Element(Pre.Mesh.Nodes(idx,:), Pre.Mesh.Normals(idx,:), ...
                       Pre.Material.t, Pre.Material.E, Pre.Material.nu);
    [xi, eta] = ndgrid(g_pts, g_pts);
    [detJ, ~, ~, ~] = el.calculateKinematics(xi(:), eta(:));
    if min(detJ) <= 0
        fprintf('Element %d: negative Jacobian!\n', e); ok = false;
    elseif max(detJ)/min(detJ) > threshold
        fprintf('Element %d: distortion ratio %.1f\n', e, max(detJ)/min(detJ));
    end
end
end
```

### Node fusion tolerance
- Default: `1e-5` (safe for meshes where shortest edge > 1e-3)
- For very fine meshes or small geometries: `tol = min_edge_length / 100`
- After `fuseNodes`, verify: `size(Pre.Mesh.Nodes,1)` should reduce by the number of interface nodes.

---

## SK-10 — Post-Processing & Stress Recovery

**Domain**: Visualization Expert

### SPR (Superconvergent Patch Recovery) — preferred over simple averaging

1. For each node, collect all Gauss-point stress values from elements sharing that node.
2. Fit a polynomial (linear for serendipity elements) to the GP values using least squares.
3. Evaluate the polynomial at the node location.

Simple averaging is acceptable for quick checks but underestimates peak stresses at boundaries.

### Load-displacement curve for arc-length results

The x-axis is a selected displacement DOF from `Sol.U_Hist`. The y-axis is `Sol.LambdaHist`. Both can go negative (snap-back). Plot as:
```matlab
u_node = Sol.U_Hist(dof, :);
lambda = Sol.LambdaHist;
plot(u_node, lambda, '-o');
xlabel('Displacement (m)'); ylabel('Load factor λ');
```
Do not use `abs()` — the sign is physically meaningful.

### Through-thickness yield front
For each element, at each in-plane Gauss point, report the fraction of the 5 Simpson layers where `p > 0`. Map this scalar to a colour on the shell surface. A value of 0 = fully elastic, 1 = fully yielded through the thickness.
