# Workflow: manage-project

---
trigger: "new phase | plan phase | Phase N | decompose tasks | roadmap"
agents: [Lead_Architect, Documentation_Assistant]
phase_type: planning
outputs: [task_briefs in docs/audit_tasks/, updated PROJECT_ROADMAP.md]
---

## Purpose
Used by the Lead Architect to start a new phase: define goals, decompose into atomic tasks, assign agents, and update the roadmap.

## Steps

### Step 1 — Phase Definition
State clearly:
- Phase number and name (e.g., Phase 14: Kinematic Hardening)
- Primary goal in one sentence
- Dependencies on previous phases (what must be complete first)
- Success criterion (what does "done" look like?)

### Step 2 — Task Decomposition
Break the phase into tasks, each assigned to one agent:

| Task ID | Description | Agent | Required Output |
|:--------|:------------|:------|:----------------|
| P14-A | Theory review of Ziegler rule | FEM Analyst | `Analyst_Report_Phase14_KinematicHardening.md` |
| P14-B | Implement `Material_J2KinHardening` | Core Implementer | `Implementer_Report_Phase14_Material.md` |
| P14-C | Unit tests and cyclic benchmark | Validation Scientist | `Validation_Report_Phase14_Cyclic.md` |
| P14-D | Data flow audit for back-stress α | Systems Engineer | `Systems_Report_Phase14_BackStress.md` |

### Step 3 — Write Task Briefs
Create one file per task in `docs/audit_tasks/Task_Phase{N}_{AgentRole}.md`. Each brief must contain:
- Assignee
- Objective (2–4 bullet points)
- Required output file name
- Status: `[ ] PENDING`

### Step 4 — Roadmap Update
Delegate to the Documentation Assistant:
- Add phase to `PROJECT_ROADMAP.md` with `[ ]` checkboxes.
- Add phase to `PROJECT_PLAN_REFACTORED.md` with `Status: IN-PROGRESS`.

### Step 5 — Announce
Message all assigned agents with their task brief paths and any cross-agent dependencies.

## Verification Checklist
- [ ] Every task has an assignee and a required output file name
- [ ] Task briefs exist in `docs/audit_tasks/`
- [ ] `PROJECT_ROADMAP.md` updated
- [ ] No agent has more tasks than can reasonably be completed before the next phase gate
- [ ] User has confirmed the phase plan before execution begins

---

# Workflow: review-architecture

---
trigger: "architecture review | structural health | class hierarchy | refactor proposal"
agents: [Lead_Architect, FEM_Expert_Analyst, Systems_Engineer]
phase_type: audit
outputs: [Architect_Audit_PhaseN.md in docs/dev_logs/reports/]
---

## Purpose
Systematic evaluation of the codebase's structural integrity. Run before major refactors or when technical debt is suspected.

## Steps

### Step 1 — Class Hierarchy Audit
Map all `@Class` directories in `src/`. For each:
- What does it inherit from?
- Is the inheritance logical (is a "is-a" relationship, not "has-a")?
- Does it duplicate logic from a sibling class?

### Step 2 — Interface Consistency Check
Verify that all implementations of the same conceptual interface use identical method signatures:
- `[KT, F_int, TrialHist] = assembleTangentSystem(obj, U_curr)` — consistent across all solvers?
- `[g, h, s] = constraintFn(u, lambda, u0, l0, dup, dlp, si)` — consistent across all constraint types?

### Step 3 — Dependency Mapping
Identify tight coupling. Flag any case where:
- A base class references a specific subclass by name.
- A solver contains logic that belongs in an element (or vice versa).
- A `buildElementCache` branch uses `strcmp` on a material type string (fragile — should use `isa`).

### Step 4 — Technical Debt Register
List all identified issues:

| Item | File | Severity | Recommended Action |
|:-----|:-----|:---------|:-------------------|
| `assembleForArcLength` duplicates `assembleTangentSystem` | `solveArcLengthStage.m` | Medium | Unify into base method |

### Step 5 — Report
Write `Architect_Audit_Phase{N}.md` in `docs/dev_logs/reports/`. Include the dependency map, debt register, and a prioritised refactoring proposal.

## Verification Checklist
- [ ] All `@Class` directories inventoried
- [ ] Inheritance chain traced for each class
- [ ] Interface mismatches documented
- [ ] Report written and linked in `dev_logs/index.md`

---

# Workflow: control-data-flow

---
trigger: "data flow audit | history persistence | state leak | schema check | type consistency"
agents: [Systems_Engineer]
phase_type: audit
outputs: [Systems_Report_{Phase}_{Topic}.md]
---

## Purpose
Trace data from preprocessor output through solver state to postprocessor input, verifying no corruption, loss, or type mismatch occurs at any boundary.

## Steps

### Step 1 — Identify Phase Boundary
Name the two components whose interface is being audited (e.g., `FEM_Preprocessor_v2` → `FEM_Solver_ArcLength`).

### Step 2 — Schema Verification
For each data structure crossing the boundary:
- Check column types in tables: `varfun(@class, obj.BCs)`.
- Check array dtypes: `class(obj.Mesh.Nodes)`, `class(obj.Mesh.Elements)`.
- Confirm no `NaN` or `Inf` in nodal coordinates or force vectors.

### Step 3 — State Trace (for history variables)
Trace the plastic state `(eps_p, p)` through one complete load step:
1. `buildElementCache` — is `HistoryData` initialised to zero structs?
2. `assembleTangentSystem` — is `TrialHist` populated from element output?
3. Newton loop convergence — is `TrialHist` preserved across iterations?
4. `commitHistory` — is it called exactly once after convergence, never on failure?
5. Next step's `assembleTangentSystem` — does it read the committed history?

### Step 4 — Shadow Data Check
Search for any logic that reads or writes solver state without going through the established API:
- Direct assignment to `obj.Elements{e}.HistoryData` outside `commitHistory`.
- Reassembly of `F_ext` inside a closure without using `calculateGlobalTargetForce`.

### Step 5 — Report
Write `Systems_Report_{Phase}_{Topic}.md`. For any `FAIL`, include the exact file:line and a recommended fix.

## Verification Checklist
- [ ] All invariants from the Systems Engineer instruction file checked
- [ ] History trace completed for at least one full load step
- [ ] No shadow data paths found (or documented and flagged)
- [ ] Report written with explicit PASS/FAIL per invariant

---

# Workflow: add-element-type

---
trigger: "new element | add element | Curve8Element_* | element formulation"
agents: [FEM_Expert_Analyst, Core_Implementer, Validation_Scientist]
phase_type: implementation
outputs: [Analyst report, new @ClassName/ in src/, tests in tests/unit/, Implementer report, Validation report]
---

## Purpose
End-to-end procedure for introducing a new `Curve8Element_*` subclass.

## Steps

### Step 1 — Theory (FEM Expert Analyst)
Issue task to Analyst: provide the mathematical basis for the new element, including:
- Integration scheme (in-plane Gauss points, through-thickness layers)
- B-matrix formulation changes vs. base element
- Any enhanced strain (EAS) or assumed natural strain (ANS) parameters
- Expected rank of stiffness matrix (number of zero-energy modes)
- Patch test prediction

### Step 2 — Design Review (Lead Architect)
Review Analyst report. Approve or request changes before any code is written.

### Step 3 — Implementation (Core Implementer)
Create `src/@Curve8Element_{Name}/`:
- Main class file inheriting from `Curve8Element`
- Override only the methods that differ from the base
- Add dispatch case in `FEM_Solver.buildElementCache` (use `isa` check, not string comparison if possible)
- Add case to `mat.ElementType` dispatch if a new type string is needed

### Step 4 — Unit Tests (Validation Scientist)
Create `tests/unit/TestCurve8Element_{Name}.m` covering:
- Stiffness matrix symmetry (error < 1e-14 × max diagonal)
- Zero-energy mode count matches prediction from Analyst report
- Patch test: uniform strain field → correct energy
- Curved element: stiffness ratio vs. baseline < 1.0 (softer, confirming locking reduction)

### Step 5 — Integration Test (Validation Scientist)
Run an existing benchmark (e.g., Scordelis-Lo) with the new element type. Confirm result matches baseline within 1%.

### Step 6 — Documentation
- Session log by the Implementer
- Implementer report listing all files created/modified
- Validation report with test results
- Update `PROJECT_FILE_REFERENCE.md`

## Verification Checklist
- [ ] Analyst PASS verdict obtained before coding begins
- [ ] Class inherits correctly; only differing methods overridden
- [ ] `buildElementCache` dispatches to new element without breaking existing cases
- [ ] All unit tests pass
- [ ] Benchmark regression confirms no impact on existing element types
- [ ] All three reports filed

---

# Workflow: debug-nonlinear-convergence

---
trigger: "convergence failure | divergence | solver fails | imaginary roots | residual grows"
agents: [FEM_Expert_Analyst, Core_Implementer, Validation_Scientist]
phase_type: audit
outputs: [Bug report or Implementer fix report]
---

## Purpose
Systematic diagnosis of nonlinear solver convergence failures.

## Steps

### Step 1 — Reproduce Deterministically
Isolate the failure to a minimal reproducible case (fewest elements, simplest load).
Log: element count, load step size, arc-length radius, error message.

### Step 2 — Classify the Failure
| Symptom | Likely Cause | Who to involve |
|:--------|:-------------|:---------------|
| Residual oscillates or grows monotonically | Wrong tangent stiffness (KT not consistent with F_int) | FEM Analyst |
| `rcond(KT) ≈ 0` on first step | Singular system — BC not applied to free-DOF partition | Systems Engineer |
| Converges but `p = 0` everywhere | History not committed (`commitHistory` missing) | Systems Engineer |
| Correct path up to limit point, then diverges | Arc-length radius too large; reduce `ArcLengthRadius` | Core Implementer |
| Imaginary roots in predictor | CSP sign detection broken; `dup_prev` not updated | Core Implementer |
| Quadratic convergence lost after plastic step | ATM not consistent with stress return | FEM Analyst |

### Step 3 — Add Targeted Logging
In `newtonLoop` or `arcLengthStep`, temporarily print:
- `‖R(free_dofs)‖` at each iteration
- `rcond(KT(free_dofs, free_dofs))`
- `dl` (load factor increment) in arc-length

### Step 4 — Fix and Verify
Implement the fix. Re-run the minimal case. Confirm quadratic convergence. Then run the full benchmark suite.

### Step 5 — Document
Write a session log describing the root cause and fix. If a regression test would have caught this, add it to `tests/unit/`.

## Verification Checklist
- [ ] Failure reproduced with minimal case
- [ ] Root cause identified from classification table
- [ ] Fix applied and convergence confirmed (quadratic in elastic regime)
- [ ] Full regression suite passes after fix
- [ ] Session log and (if applicable) implementer report written

---

# Workflow: run-unit-tests

---
trigger: "run tests | unit tests | after src change | verify fix"
agents: [Validation_Scientist]
phase_type: verification
outputs: [Test pass/fail summary, Validation report if failures found]
---

## Steps
1. `matlab -batch "setup_project; runtests('tests/unit');"` — unit tests
2. `matlab -batch "setup_project; runtests('tests/Patchtest');"` — patch tests
3. If failures: inspect stack trace, identify root cause in `src/`, tag Core Implementer.
4. If pass: confirm in session log and notify Lead Architect.
5. If this is a new feature: confirm a new test was added for it before marking complete.

## Verification Checklist
- [ ] All existing unit tests pass
- [ ] All patch tests pass
- [ ] New tests cover any changed behaviour
- [ ] `dev_logs/` entry created

---

# Workflow: audit-reporting

---
trigger: "audit reports | check reports | are all tasks done | phase gate"
agents: [Documentation_Assistant, Lead_Architect]
phase_type: documentation
outputs: [audit summary in conversation or brief report]
---

## Steps
1. List all files in `docs/audit_tasks/` for the phase being closed.
2. For each task file, check: does it contain a `Status: COMPLETED` line? Does it contain a report link?
3. Verify each linked report file actually exists in `docs/dev_logs/reports/`.
4. List any tasks that are `IN-PROGRESS`, missing a report, or have a broken report link.
5. Report findings to the Lead Architect. If all tasks are complete, confirm phase is ready to close.

## Verification Checklist
- [ ] Every task brief has `Status: COMPLETED` or is explicitly carried to next phase
- [ ] Every completed task has a linked, existing report file
- [ ] `dev_logs/index.md` has an entry for the phase
- [ ] `PROJECT_ROADMAP.md` checkbox is updated

---

# Workflow: sync-docs

---
trigger: "sync docs | update roadmap | documentation sync | phase complete"
agents: [Documentation_Assistant]
phase_type: documentation
outputs: [Updated PROJECT_ROADMAP.md, PROJECT_PLAN_REFACTORED.md, dev_logs/index.md]
---

## Steps
1. Read the most recent Lead Architect phase completion report.
2. Update `PROJECT_ROADMAP.md`: set completed items to `[x]`, in-progress to `[/]`.
3. Update `PROJECT_PLAN_REFACTORED.md`: set Status and Date for the closed phase.
4. Add entry to `dev_logs/index.md` with date, phase number, topic, agent, status, and log link.
5. Scan all document links — flag any `file:///` paths (they are machine-local and won't work for other users; convert to relative paths).
6. Confirm to the Lead Architect.

## Verification Checklist
- [ ] `PROJECT_ROADMAP.md` reflects actual state
- [ ] `PROJECT_PLAN_REFACTORED.md` updated
- [ ] `index.md` has the new entry
- [ ] No broken or machine-local file links remain
