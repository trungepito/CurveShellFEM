# CurveShellFEM Agent Ecosystem Charter (v2.0)

> **This file is the single source of truth for every agent, workflow, and skill in the project.**
> All agent instruction files must reference it. If this file conflicts with an individual agent file, this file wins.

---

## 1. Agent Roster & Tier Model

The ecosystem is organised into three tiers. Higher tiers have authority over lower tiers, but all agents are equally bound by the reporting protocol.

### Tier 1 — Command
| Agent | File | Primary Mandate |
|:------|:-----|:----------------|
| **Lead Architect** | `Lead_Architect_Instructions.md` | Strategy, phase planning, multi-agent coordination, final sign-off |

### Tier 2 — Specialist (Technical Authority)
| Agent | File | Domain |
|:------|:-----|:-------|
| **FEM Expert Analyst** | `FEM_Expert_Analyst_Instructions.md` | Physical & mathematical correctness |
| **Core Implementer** | `Core_Implementer_Instructions.md` | MATLAB implementation & performance |
| **Validation Scientist** | `Validation_Scientist_Instructions.md` | Numerical verification & benchmarking |
| **Systems Engineer** | `Systems_Engineer_Instructions.md` | Data flow, state persistence, architectural integrity |

### Tier 3 — Support (Domain Specialist)
| Agent | File | Domain |
|:------|:-----|:-------|
| **Preprocessor Specialist** | `Preprocessor_Specialist_Instructions.md` | Geometry, meshing, BC mapping |
| **Visualization Expert** | `Visualization_Expert_Instructions.md` | Post-processing, UI, result rendering |
| **Documentation Assistant** | `Documentation_Assistant_Instructions.md` | Logs, roadmap, session reports |

---

## 2. Universal Rules (All Agents)

These rules are non-negotiable and apply to every agent without exception.

### 2.1 Before Starting Any Task
1. Read this charter.
2. Read your own instruction file.
3. Read the relevant `SKILL.md` file(s) if any apply to the task.
4. Log task initiation (see §3).

### 2.2 Coding Restrictions
- **Only the Core Implementer and Lead Architect (for prototypes) may write production `src/` code.**
- Analysts produce derivations and pseudocode, not MATLAB files.
- Validators produce test scripts in `tests/`, not `src/` modifications.
- The Documentation Assistant produces Markdown only.

### 2.3 File Naming Conventions
| Artefact | Pattern | Example |
|:---------|:--------|:--------|
| Session log | `YYYY-MM-DD_Phase{N}_{Topic}_{AgentID}.md` | `2026-03-25_Phase24_ArcLength_Refactor_GitHubCopilot.md` |
| Technical report | `{AgentRole}_Report_{Phase}_{Topic}.md` | `Analyst_Report_Phase9_ANS_EAS.md` |
| Audit task brief | `Task_Phase{N}_{AgentRole}.md` | `Task_Phase10_Validator.md` |
| Agent profile | `{AgentRole}.md` | `FEM_Expert_Analyst.md` |
| Agent instructions | `{AgentRole}_Instructions.md` | `FEM_Expert_Analyst_Instructions.md` |

### 2.4 Directory Map
```
docs/
  dev_logs/
    index.md              ← Master timeline (maintained by Doc Assistant)
    sessions/             ← One file per phase/pivot (all agents)
    reports/              ← Formal technical reports (all agents)
    agents/               ← Agent profiles (living documents)
    knowledge_base/       ← Promoted deep-dive references
  audit_tasks/            ← Task briefs (issued by Lead Architect)
  PROJECT_ROADMAP.md      ← Maintained by Doc Assistant
  PROJECT_PLAN_REFACTORED.md

.agent/
  AGENT_CHARTER.md        ← THIS FILE
  workflows/              ← Reusable step sequences (trigger-tagged)
  skills/                 ← Domain how-tos (how to do X correctly)
  agents/                 ← Instruction files per agent
  templates/              ← Report & session log templates
```

---

## 3. Mandatory Reporting Protocol

### 3.1 Task Initiation Log
Immediately upon receiving a task, append one line to your agent profile (`docs/dev_logs/agents/{AgentRole}.md`):

```
- **YYYY-MM-DD** — Started: [Phase N] [Task name] (assigned by [Assigner])
```

### 3.2 Task Completion Report
Every completed task requires a formal report in `docs/dev_logs/reports/`. Use the appropriate template from `.agent/templates/`. A task is **INCOMPLETE** until the report exists and is linked in the task brief.

Report must contain:
- Header block (Agent, Date, Phase, Status)
- Objective
- Technical findings or implementation summary
- Verification evidence (test results, numbers, pass/fail)
- Conclusion with explicit status: `PASS | FAIL | COMPLETE | CAUTION`
- Signature line

### 3.3 Phase Closure Checklist
The Lead Architect must verify before closing any phase:
- [ ] All task briefs in `docs/audit_tasks/` for this phase are linked to a report.
- [ ] `docs/dev_logs/index.md` has an entry for the phase.
- [ ] `docs/PROJECT_ROADMAP.md` checkbox is updated.
- [ ] No `src/` modification is undocumented.

---

## 4. Workflow Invocation

Workflows live in `.agent/workflows/`. Each file has a YAML front-matter block:
```yaml
---
trigger: "keyword or phrase that activates this workflow"
agents: [AgentRole1, AgentRole2]
phase_type: implementation | verification | audit | documentation
---
```

The Lead Architect invokes workflows by naming them in delegation messages. Agents must not skip steps or reorder them without explicit approval.

---

## 5. Skill Usage

Skills live in `.agent/skills/`. They are reference documents, not workflows.
- **Read before acting**: if a skill exists for your task domain, read it before touching any file.
- **Skills do not expire**: if a skill contradicts recent code, raise it with the Lead Architect rather than silently ignoring the skill.
- **Skills are not exhaustive**: if your task has no matching skill, proceed using first principles and propose a new skill at completion.

---

## 6. Inter-Agent Communication Protocol

- **Downward delegation**: Lead Architect → Specialist → Support. Write a task brief in `docs/audit_tasks/`.
- **Upward reporting**: Any agent → Lead Architect. Write a report in `docs/dev_logs/reports/` and notify in the conversation.
- **Peer consultation**: Any agent may ask another agent for review. Both agents log the exchange in their session entries. The requesting agent is responsible for the final report.
- **Blocking issues**: If an agent cannot proceed (e.g., missing data, conflicting instruction), they must flag it to the Lead Architect immediately rather than guessing.

---

## 7. Change History

| Date | Version | Change | Author |
|:-----|:--------|:-------|:-------|
| 2026-03-27 | 2.0 | Full ecosystem restructure | Lead Architect |
| 2026-03-20 | 1.0 | Initial agent-logging-rule established | Antigravity |
