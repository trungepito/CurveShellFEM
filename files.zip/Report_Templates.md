# Report Templates (v2.0)

> Copy the appropriate template. Replace all `[...]` placeholders. Delete unused optional sections.
> File naming: `{AgentRole}_Report_{Phase}_{Topic}.md` — e.g. `Analyst_Report_Phase9_ANS_EAS.md`

---

## Template A — Analyst Report

```markdown
# Analyst Report: [Topic] — Phase [N]

**Agent**: FEM Expert Analyst
**Date**: YYYY-MM-DD
**Phase**: [N]
**Status**: DRAFT | PASS | REFINE | CAUTION | REJECT

---

## 1. Objective
[What physical/mathematical component is being reviewed? One paragraph.]

## 2. Theoretical Reference
[Author, year, equation numbers. This is the "ground truth".]

## 3. Theory vs. Implementation

| Feature | Theory | Code (file:line) | Verdict |
|:--------|:-------|:-----------------|:--------|
| [e.g. Residual sign] | F_int − λF_ext | `arcLengthStep.m:L88` | Match |
| [e.g. ATM consistency] | Consistent | Elastic fallback | MISMATCH |

## 4. Detailed Findings
[Mathematical derivation or verification. Equations, Jacobian checks, energy arguments.]

## 5. Risks
- **Risk 1 [Priority]**: [Description]
- **Risk 2 [Priority]**: [Description]

## 6. Recommendations
1. [Actionable item with priority: HIGH | MEDIUM | LOW | DOCUMENTATION]
2. ...

## 7. Verdict
**[PASS | REFINE | CAUTION | REJECT]** — [One-sentence justification]

---
*Signed, FEM Expert Analyst — YYYY-MM-DD*
```

---

## Template B — Validation Report

```markdown
# Validation Report: [Test Case] — Phase [N]

**Agent**: Validation Scientist
**Date**: YYYY-MM-DD
**Phase**: [N]
**Status**: PASS | FAIL | WARNING

---

## 1. Objective
[What is being validated and why?]

## 2. Methodology
- **Reference**: [Timoshenko / Scordelis-Lo / Crisfield / internal baseline]
- **Mesh**: [N×M structured / unstructured, element type]
- **Solver**: [Linear / NR / Arc-Length, tolerance, max iterations]
- **Script**: `examples/[script_name].m`

## 3. Numerical Results

| Metric | Reference | Result | Error (%) | Status |
|:-------|:----------|:-------|:----------|:-------|
| [Max displacement] | [0.3024] | [0.3020] | [0.13] | ✅ PASS |
| [Limit point load] | — | [Converged] | — | ✅ PASS |

## 4. Convergence Analysis
- Iterations per step: [3–6 typical]
- Final residual norm: `‖R‖ = [value]`
- [ ] Quadratic convergence observed in elastic regime

## 5. Regression Check
[List any previously passing benchmarks re-run in this validation. Confirm no regression.]

## 6. Verdict
**[PASS | FAIL | WARNING]** — [One-sentence justification and any follow-up action]

---
*Signed, Validation Scientist — YYYY-MM-DD*
```

---

## Template C — Implementer Report

```markdown
# Implementer Report: [Topic] — Phase [N]

**Agent**: Core Implementer
**Date**: YYYY-MM-DD
**Phase**: [N]
**Status**: COMPLETE | IN-PROGRESS

---

## 1. Objective
[What was built or refactored?]

## 2. Files Changed

| File | Action | Notes |
|:-----|:-------|:------|
| `src/@ClassName/method.m` | Created | New arc-length constraint |
| `src/@OtherClass/method.m` | Modified | Updated to use new interface |
| `src/@LegacyClass/` | Deleted | Replaced by unified element |

## 3. Design Decisions
[Non-obvious implementation choices and their rationale. Reference the Analyst report where applicable.]

## 4. Known Limitations / Follow-up
- [Item 1]
- [Item 2]

## 5. Verification
- [ ] `runtests('tests/unit')` — all pass
- [ ] `runtests('tests/Patchtest')` — all pass
- [ ] No modification to validated baseline benchmarks

---
*Signed, Core Implementer — YYYY-MM-DD*
```

---

## Template D — Systems Engineer Report

```markdown
# Data Health Report: [Topic] — Phase [N]

**Agent**: Systems & Consistency Engineer
**Date**: YYYY-MM-DD
**Phase**: [N]
**Status**: PASS | FAIL | WARNING

---

## 1. Audit Scope
[Which phase boundary or data flow was audited?]

## 2. Invariants Checked

| Invariant | Result | Evidence |
|:----------|:-------|:---------|
| `Mesh.Nodes` is double | ✅ PASS | `class(Pre.Mesh.Nodes) = 'double'` |
| History committed once per step | ❌ FAIL | `commitHistory` not called in `solveArcLengthStage.m:L206` |

## 3. Discrepancies Found
[Detailed description of any data flow breaks, type mismatches, or state leaks. Include file and line references.]

## 4. Recommended Fixes
1. [Specific fix with file:line reference]
2. ...

## 5. Verdict
**[PASS | FAIL]** — [Summary]

---
*Signed, Systems & Consistency Engineer — YYYY-MM-DD*
```

---

## Template E — Lead Architect Phase Completion Report

```markdown
# Lead Architect Report: Phase [N] Completion

**Date**: YYYY-MM-DD
**Phase**: [N] ([Phase Name])
**Status**: COMPLETED
**Approval**: Lead Architect

---

## 1. Executive Summary
[One paragraph: what was achieved, what risk was addressed, what is now possible.]

## 2. Key Accomplishments

| Component | Achievement | Verification |
|:----------|:------------|:-------------|
| [Component] | [What was done] | [How it was verified] |

## 3. Agent Deliverables Audit

- [x] **FEM Analyst**: [Report link] — [verdict]
- [x] **Core Implementer**: [Report link] — [completion note]
- [x] **Validation Scientist**: [Report link] — [benchmark result]
- [x] **Systems Engineer**: [Report link] (if applicable)

## 4. Architectural Notes
[Design decisions made, trade-offs accepted, and their long-term implications.]

## 5. Authorization for Phase [N+1]
[Explicit statement. Name the next phase and its primary goal.]

---
*Signed, Lead Architect — YYYY-MM-DD HH:MM*
```
